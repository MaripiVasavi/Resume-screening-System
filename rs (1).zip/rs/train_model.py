# train_model.py
import pandas as pd
import re
import pickle
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.naive_bayes import MultinomialNB

def preprocess_text(text):
    text = re.sub(r"http\S+", " ", text)
    text = re.sub(r"RT|cc", " ", text)
    text = re.sub(r"#\S+|@\S+", " ", text)
    text = re.sub(r"[%s]" % re.escape("\r\n\t"), " ", text)
    text = re.sub(r"[^a-zA-Z0-9]+", " ", text)
    return text.strip()

df = pd.read_csv(r"C:\Users\Admin\OneDrive\Desktop\rs\UpdatedResumeDataSet.csv")
df["cleaned_resume"] = df["Resume"].apply(preprocess_text)

vectorizer = TfidfVectorizer(stop_words="english")
X = vectorizer.fit_transform(df["cleaned_resume"])
y = df["Category"]

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

model = MultinomialNB()
model.fit(X_train, y_train)

# Save model and vectorizer
with open("model/resume_model.pkl", "wb") as f:
    pickle.dump(model, f)
with open("model/vectorizer.pkl", "wb") as f:
    pickle.dump(vectorizer, f)

print("Model and vectorizer saved successfully.")
