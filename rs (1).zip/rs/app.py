# app.py
from flask import Flask, request, jsonify, render_template
import os
import re
import pickle
import fitz  # PyMuPDF
import docx
from werkzeug.utils import secure_filename

app = Flask(__name__)
UPLOAD_FOLDER = 'uploads'
ALLOWED_EXTENSIONS = {'pdf', 'docx', 'txt'}
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

# Load model and vectorizer
with open("model/resume_model.pkl", "rb") as f:
    model = pickle.load(f)
with open("model/vectorizer.pkl", "rb") as f:
    vectorizer = pickle.load(f)

# Preprocess resume text
def preprocess_text(text):
    text = re.sub(r"http\S+", " ", text)
    text = re.sub(r"RT|cc", " ", text)
    text = re.sub(r"#\S+|@\S+", " ", text)
    text = re.sub(r"[%s]" % re.escape("\r\n\t"), " ", text)
    text = re.sub(r"[^a-zA-Z0-9]+", " ", text)
    return text.strip()

# Extract text from PDF
def extract_text_from_pdf(path):
    text = ""
    with fitz.open(path) as doc:
        for page in doc:
            text += page.get_text()
    return text

# Extract text from DOCX
def extract_text_from_docx(path):
    doc = docx.Document(path)
    return "\n".join(p.text for p in doc.paragraphs)

# Extract text from TXT
def extract_text_from_txt(path):
    with open(path, 'r', encoding='utf-8', errors='ignore') as f:
        return f.read()

# File extension check
def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@app.route("/")
def home():
    return render_template("frontend.html")

@app.route("/upload", methods=["POST"])
def upload_resume():
    if "resume" not in request.files:
        return jsonify({"error": "No file uploaded"}), 400

    files = request.files.getlist("resume")
    if not files:
        return jsonify({"error": "No files selected"}), 400

    results = []

    for file in files:
        if file.filename == "" or not allowed_file(file.filename):
            results.append({"filename": file.filename, "error": "Unsupported or empty file"})
            continue

        filename = secure_filename(file.filename)
        file_path = os.path.join(app.config["UPLOAD_FOLDER"], filename)
        file.save(file_path)

        ext = filename.rsplit('.', 1)[1].lower()
        if ext == "pdf":
            text = extract_text_from_pdf(file_path)
        elif ext == "docx":
            text = extract_text_from_docx(file_path)
        elif ext == "txt":
            text = extract_text_from_txt(file_path)
        else:
            results.append({"filename": filename, "error": "Unsupported file type"})
            continue

        cleaned = preprocess_text(text)
        vector = vectorizer.transform([cleaned])
        prediction = model.predict(vector)[0]

        results.append({
            "filename": filename,
            "predicted_category": prediction
        })

    return jsonify(results)

if __name__ == "__main__":
    app.run(debug=True)
