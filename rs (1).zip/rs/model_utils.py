# model_utils.py

import random

# Mock function to simulate category prediction
def predict_category(text):
    categories = ['Data Scientist', 'Software Engineer', 'Web Developer', 'AI Engineer']
    predicted_category = random.choice(categories)
    confidence_score = round(random.uniform(0.75, 0.99), 2)
    return predicted_category, confidence_score